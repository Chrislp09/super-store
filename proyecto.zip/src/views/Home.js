import React, { useEffect, useState } from 'react';
import { getAll } from '../action/index';
import ProductsList from '../components/products/ProductList';
import api from '../utils/api';
import config from '../utils/config';

const Home = ({ showLoader }) => {
  const [data, setData] = useState([]);
  const [count, setCount] = useState(5);

  const viewData = async() => {
    showLoader(true);
    let getLimit = count > 0? {limit: count.toString()}: {}
    await api.get(config.apiStoreAll, getLimit).then(res => {
      if(res.code === 200) {
        if(count > res.data.length) {
          alert('Ya no hay mas productos que cargar')
          setCount(res.data.length);  
        } else {
          setData(res.data);
        }
      }
      showLoader(false);
    }).catch((err) => {
      showLoader(false);
    })
  }

  useEffect(() => {
    viewData();
  }, [count])
  return (
    <>
      <div className="home">
        <h1>Bienvenido a Super Store</h1>
        <p>La mejor calidad en productos.</p>
      </div>
      <div>
        <ProductsList 
          data={data}
          count={count}
          setCount={setCount}
        />
      </div>
    </>
  )
};

export default Home;