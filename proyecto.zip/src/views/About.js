import React from 'react';

const About = () => (
  <div className="about">
    <h1>Acerca de nosotros</h1>
    <p>Somos una empresa dedicada a brindar soluciones innovadoras.</p>
  </div>
);

export default About;