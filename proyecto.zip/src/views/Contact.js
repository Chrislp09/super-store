import React from 'react';

const Contact = () => (
  <div className="contact">
    <h1>Contáctanos</h1>
    <p>Puedes enviarnos un correo electrónico a contact@example.com</p>
  </div>
);

export default Contact;