import React, { useState } from 'react';

const ItemProduct = ({ product }) => {
    const [data, setProduct] = useState({
        title: product?.title || "",
        image: product?.image || "",
        description: product?.description || "",
        price: product?.price || "",
        category: product?.category || "",
        rating: product?.rating?.rate || "",
        count: product?.rating?.count || "",
    })
    const truncatedDescription = product.description.length > 200
    ? `${product.description.slice(0, 150)}...`
    : product.description;

  return (
    <div className="product-card">
      <img src={data.image} alt={data.title} />
      <h3>{data.title}</h3>
      <p className="description">{truncatedDescription}</p>
      <div className="product-details">
        <p>Categoría: {data.category}</p>
      </div>
      <div className="product-details">
        <p>Precio: {data.price}</p>
        <p>Rating: {data.rating}</p>
        <p>Stock: {data.count}</p>
        <button>Agregar al carrito</button>
      </div>
    </div>
  );
};

export default ItemProduct;
