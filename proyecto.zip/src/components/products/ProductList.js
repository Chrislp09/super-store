import React, { useState, useEffect } from 'react';
import ItemProduct from './ItemProducts'; 

const ProductsList = ({ data, count, setCount }) => {

  if (data.length === 0) {
    return <p>No hay productos por mostrar.</p>;
  }

  return (
    <div className="products-list">
      {data.slice(0, count).map((product, index) => (
        <ItemProduct key={product.id} product={product} />
      ))}
      {data.length > 0 && (
        <button className="empty-message" onClick={() => setCount(prevCount => prevCount + 5)}>Cargar más</button>
      )}
    </div>
  );
};

export default ProductsList;
