import api from "../utils/api";
import Config from "../utils/config";

export const getAll = async(params) => {
    let res = await api.getParams(Config.apiStoreAll, params);
    return res;
}